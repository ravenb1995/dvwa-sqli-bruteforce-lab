
# 🧪 DVWA SQL Injection & Brute Force Lab

This project simulates a penetration test against Damn Vulnerable Web App (DVWA). It includes SQL injection, brute-force login attempts, and walkthrough documentation with screenshots.

## ✅ What You’ll Learn
- SQL injection basics
- Hydra brute-force login
- Burp Suite analysis
- Web vulnerability testing

## 📂 Contents
- `walkthrough.md`: Step-by-step guide
- `screenshots/`: Visual documentation
- `LICENSE`: MIT License
